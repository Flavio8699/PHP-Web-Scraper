How to install?

1) Download the source code
2) Download XAMPP with PHP Version 7.3.10 https://www.apachefriends.org/download.html
3) Install XAMPP
4) Open folder "htdocs" in XAMPP files
5) Delete everything inside
6) Copy & Paste the source code from the project into "htdocs"
7) Open XAMPP
8) Run Apache Web Server
9) Run http://localhost/ on your web browser
